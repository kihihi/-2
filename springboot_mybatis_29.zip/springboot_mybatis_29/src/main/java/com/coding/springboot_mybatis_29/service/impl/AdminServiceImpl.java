package com.coding.springboot_mybatis_29.service.impl;

import com.coding.springboot_mybatis_29.entity.Admin;
import com.coding.springboot_mybatis_29.entity.Cp;
import com.coding.springboot_mybatis_29.entity.Customer;
import com.coding.springboot_mybatis_29.mapper.AdminMapper;
import com.coding.springboot_mybatis_29.service.AdminService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Slf4j
@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    AdminMapper am;

//    @Override
//    public boolean login(Admin admin) {
//        Admin login = am.login(admin);
//        if (login != null) {
//            return true;
//        } else {
//            return false;
//        }
//    }
//
//    @Override
//    public List<Customer> selectAll() {
//        List<Customer> customers = am.selectAll();
//        return customers;
//    }
//
//    @Override
//    public boolean register(String tel, String confirm, String password, String confirmPwd) {
//        // 实现注册业务逻辑
//        // 手机号重复性验证
//        Customer customer = am.selectByTel(tel);
//        if (customer == null) {
//            // 密码的一致性验证
//            if (password.equals(confirmPwd)) {
//                boolean b = am.addCustomer(tel);
//                return b;
//            } else {
//                return false;
//            }
//        } else {
//            return false;
//        }
//    }
//
//    @Override
//    public List<Customer> select(Integer id, String name, Integer minScore, Integer maxScore, String tel, String sex) {
//        List<Customer> customers = am.selectDynamic(id, name, minScore, maxScore, tel, sex);
//        return customers;
//    }
//
//    @Override
//    public Customer selectById(Integer id) {
//        Customer customer = am.selectById(id);
//        return customer;
//    }
//
//    @Override
//    public boolean updateCustomer(Customer customer) {
//        boolean b = am.updateCustomer(customer);
//        return b;
//    }
//
//    @Override
//    public boolean deleteCustomer(Integer id) {
//        boolean b = am.deleteCustomer(id);
//        return b;
//    }
//
//    @Override
//    public boolean insertCustomer(Customer customer) {
//        boolean b = am.insertCustomer(customer);
//        return b;
//    }

    @Override
    public boolean insertCustomer1(Cp cp) {

//        // TODO:20230212 add
//        String cp_nameSei = Cp.getCP_NameSei();
//
//        // TODO:输入的数据为空
//        if(StringUtils.isEmpty(cp_nameSei)){
////            return JsonResult.fail();
//
//            return false;
//        }
//        // TODO:输入的数据长度超过40，这里的40是字数
//        if(cp_nameSei.length()>40){
////            return JsonResult.fail();
//            return false;
//        }


        boolean b = am.insertCustomer1(cp);
        return b;
    }

    @Override
    public boolean save(Cp cp) {
        return am.save(cp)==1;
    }

    @Override
    public boolean savegua(Cp cp) {
        return am.savegua(cp)==1;
    }
}
