package com.coding.springboot_mybatis_29.mapper;

import com.coding.springboot_mybatis_29.entity.Admin;
import com.coding.springboot_mybatis_29.entity.Customer;
import com.coding.springboot_mybatis_29.entity.Cp;

import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper

public interface AdminMapper {

//    // 根据账号密码查询
//    Admin login(Admin admin);
//
//    // 会员信息全查询
//    @Select("select id, name, score, sex, tel from customer")
//    List<Customer> selectAll();
//
//    // 根据手机号查询
//    @Select("select id, name, score, sex, tel from customer where tel = #{value}")
//    Customer selectByTel(String tel);
//
//    // 添加
//    @Insert("insert into customer(tel) values(#{value})")
//    boolean addCustomer(String tel);
//
//    // 声明搜索的动态查询方法
//    List<Customer> selectDynamic(
//            @Param("id") Integer id,
//            @Param("name") String name,
//            @Param("minScore") Integer minScore,
//            @Param("maxScore") Integer maxScore,
//            @Param("tel") String tel,
//            @Param("sex") String sex);
//
//    // 根据id查询会员所有信息
//    @Select("select id, name, score, tel, sex from customer where id = #{value}")
//    Customer selectById(Integer id);
//
//    // 根据id修改会员其他信息
//    @Update("update customer set name = #{name}, score = #{score}, tel = #{tel}, sex = #{sex} where id = #{id}")
//    boolean updateCustomer(Customer customer);
//
//    @Delete("delete from customer where id = #{value}")
//    boolean deleteCustomer(Integer id);
//
//    @Insert("insert into customer values(#{id}, #{name},#{sex},#{score}, #{tel})")
//    boolean insertCustomer(Customer customer);



    // 点火SQL文法  （TODO:SQL语法没毛病）
    @Insert("insert into Cp values (#{CP_NameSei},#{CP_NameMei},#{CP_NameSeiKana},#{CP_NameMeiKana},#{CP_AlphLastname},#{CP_AlphFirstname},#{CP_Country},#{CP_Sex},#{CP_BirthDate},#{CP_ShokugyoCode},#{CP_KinmusakiName})")
    boolean insertCustomer1(Cp cp);

    int save(Cp cp);

    int savegua(Cp cp);
}


