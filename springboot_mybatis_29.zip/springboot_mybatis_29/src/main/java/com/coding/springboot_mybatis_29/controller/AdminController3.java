package com.coding.springboot_mybatis_29.controller;


import com.coding.springboot_mybatis_29.entity.Cp;
import com.coding.springboot_mybatis_29.service.AdminService;
import com.coding.springboot_mybatis_29.util.JsonResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;


@Controller
@RequestMapping("/customerController")
@Slf4j
public class AdminController3 {

    @Autowired
    AdminService as;


    /**
     * @return
     */
    @RequestMapping("/goAdd1")
    public String goAdd1() {
        return "add3";
    }

    @RequestMapping("/doAdd1")
    @ResponseBody
//    @CrossOrigin
    public JsonResult<Cp> doAdd1(@RequestBody Cp cp) {

        // TODO：テスト用
//        cp.setCP_NameSei("漢字222");

        // TODO:テータの類型は必ず設置する。しないと、SQLはバグする（日期类型一定要设置，否则SQL执行会报以下错）
        // insert into Cp values ('漢字222','','','','','','','','','','')
        //> 1292 - Incorrect date value: '' for column 'CP_BirthDate' at row 1
        //> 时间: 0s
//        cp.setCP_BirthDate(new Date());

        boolean b = as.insertCustomer1(cp);

        if (b) {
//            model.addAttribute("cp", cp);
//            return "addSuc1";

            return JsonResult.success(cp);

        } else {
//            model.addAttribute("errorMsg", "添加失败,请重试");
//            return "add1";

            return JsonResult.fail();
        }
    }


    @RequestMapping(value = "/doAdd12", method = RequestMethod.POST)
    public JsonResult savegua(@RequestBody Cp cp) {
        // 戻り値を作成する（创建返回值）
        JsonResult<Void> result = new JsonResult<Void>();

        try {
            //
            //ビジネス オブジェクトを移行し、登録を行う（调用业务对象执行注册）
            as.insertCustomer1(cp);
            // 反応成功（响应成功）
            result.setState(200);
        } catch (Exception e) {
            // ユーザネームは使用された（用户名被占用）
            result.setState(4000);
            result.setMessage("异常发生");
        }
        // 結果を戻す
        return result;
    }



}
