package com.coding.springboot_mybatis_29.service;

import com.coding.springboot_mybatis_29.entity.Admin;
import com.coding.springboot_mybatis_29.entity.Cp;
import com.coding.springboot_mybatis_29.entity.Customer;

import java.util.List;

public interface AdminService {
//
//    // 登录
//    boolean login(Admin admin);
//
//    // 会员信息全查询
//    List<Customer> selectAll();
//
//    // 会员注册方法
//    boolean register(String tel, String confirm, String password, String confirmPwd);
//
//    // 实现动态查询的方法
//    List<Customer> select(Integer id, String name, Integer minScore, Integer maxScore, String tel, String sex);
//
//    // 根据id查询会员所有信息
//    Customer selectById(Integer id);
//
//    // 根据id修改会员其他信息
//    boolean updateCustomer(Customer customer);
//
//    boolean deleteCustomer(Integer id);
//
//    // 根据画面信息完成会员添加
//    boolean insertCustomer(Customer customer);

    //個人情報追加
    boolean insertCustomer1(Cp cp);

    boolean save(Cp cp);

    boolean savegua(Cp cp);


}
