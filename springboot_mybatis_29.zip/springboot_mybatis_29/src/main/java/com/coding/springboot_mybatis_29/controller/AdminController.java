//package com.coding.springboot_mybatis_29.controller;
//
//import com.coding.springboot_mybatis_29.entity.Admin;
//import com.coding.springboot_mybatis_29.entity.Cp;
//import com.coding.springboot_mybatis_29.entity.Customer;
//import com.coding.springboot_mybatis_29.service.AdminService;
//import com.coding.springboot_mybatis_29.util.JsonResult;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.coyote.Request;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import java.util.Date;
//import java.util.List;
//
//
//@Controller
//@RequestMapping("/customerController")
//@Slf4j
//public class AdminController {
//
//    @Autowired
//    AdminService as;
//
////    @RequestMapping("/goLogin")
////    public String goLogin() {
////        return "login";
////    }
////
////    @RequestMapping("/doLogin")
////    public String doLogin(Admin admin, Model model) {
//        // 根据传递的账号和密码进行登录验证
//        // 如果登录成功,发送到首页画面
//        // 如果登录失败,返回登录页面,提示用户重新输入
////        boolean login = as.login(admin);
////        if (login) {
////            // 登陆成功,跳转首页的同时需要将所有用户的数据一起发送到首页
////            // 查询用户表的所有用户信息
////            List<Customer> customers = as.selectAll();
////            model.addAttribute("customerList", customers);
////            return "index";
////        }
////        else {
////            // 登录失败
////            model.addAttribute("errorMsg", "账号或密码不正确");
////            return "login";
////        }
////    }
//
////    @RequestMapping("/goRegister")
////    public String goRegister() {
////        return "register";
////    }
////
////    @RequestMapping("/doRegister")
////    public String doRegister(String tel, String confirm, String password, String confirmPwd, Model model) {
////        boolean register = as.register(tel, confirm, password, confirmPwd);
////        if (register) {
////            return "registerSuc";
////        }
////        else {
////            model.addAttribute("errorMsg", "注册失败");
////            return "register";
////        }
////    }
//
////    @RequestMapping("/doSelect")
////    public String doSelect(Integer id, String name, Integer minScore, Integer maxScore, String tel, String sex,
////                           Model model) {
////        List<Customer> select = as.select(id, name, minScore, maxScore, tel, sex);
////        model.addAttribute("customerList", select);
////        return "index";
////    }
////
////    @RequestMapping("/goUpdate")
////    public String goUpdate(Integer id, Model model) {
////        Customer customer = as.selectById(id);
////        model.addAttribute("cus", customer);
////        return "update";
////    }
//
////    @RequestMapping("/doUpdate")
////    public String doUpdate(Customer customer, Model model) {
////        boolean b = as.updateCustomer(customer);
////        if (b) {
////            model.addAttribute("customer", customer);
////            return "updateSuc";
////        }
////        else {
////            Customer c = as.selectById(customer.getId());
////            model.addAttribute("cus", c);
////            model.addAttribute("errorMsg", "修改失败,请重试");
////            return "update";
////        }
//////        model.addAttribute("cus", customer);
////
////    }
//
////    @RequestMapping("/goDelete")
////    public String goDelete(Integer id, Model model) {
////        model.addAttribute("id", id);
////        return "delete";
////    }
////
////    @RequestMapping("/doDelete")
////    public String doDelete(Integer id, Model model) {
////        boolean b = as.deleteCustomer(id);
////        if (b) {
////            model.addAttribute("id", id);
////            return "deleteSuc";
////        }
////        else {
////            model.addAttribute("id", id);
////            model.addAttribute("errorMsg", "删除失败,请重试");
////            return "delete";
////        }
////        model.addAttribute("cus", customer);
////    }
//
////    @RequestMapping("/goAdd")
////    public String goAdd() {
////        return "add";
////    }
////
////    @RequestMapping("/doAdd")
////    public String doAdd(Customer customer, Model model) {
////
////        System.out.println(customer.getSex());
////        boolean b = as.insertCustomer(customer);
////
////        log.info("hello");
////        if (b) {
////            model.addAttribute("customer", customer);
////            return "addSuc";
////        }
////        else {
////            model.addAttribute("errorMsg", "添加失败,请重试");
////            return "add";
////        }
////    }
//
//    /**
//     * @return
//     */
//    @RequestMapping("/goAdd1")
//    public String goAdd1() {
//        return "add1";
//    }
//
//    @RequestMapping("/doAdd1")
//    @ResponseBody
//    public JsonResult<Cp> doAdd1(@RequestBody Cp cp) {
//
//        // TODO：テスト用
////        cp.setCP_NameSei("漢字222");
//
//        // TODO:テータの類型は必ず設置する。しないと、SQLはバグする（日期类型一定要设置，否则SQL执行会报以下错）
//        // insert into Cp values ('漢字222','','','','','','','','','','')
//        //> 1292 - Incorrect date value: '' for column 'CP_BirthDate' at row 1
//        //> 时间: 0s
////        cp.setCP_BirthDate(new Date());
//
//        boolean b = as.insertCustomer1(cp);
//
//        if (b) {
////            model.addAttribute("cp", cp);
////            return "addSuc1";
//
//            return JsonResult.success(cp);
//
//        } else {
////            model.addAttribute("errorMsg", "添加失败,请重试");
////            return "add1";
//
//            return JsonResult.fail();
//        }
//    }
//
//
//    @RequestMapping(value = "/doAdd12", method = RequestMethod.POST)
//    public JsonResult savegua(@RequestBody Cp cp) {
//        // 戻り値を作成する（创建返回值）
//        JsonResult<Void> result = new JsonResult<Void>();
//
//        try {
//            //
//            //ビジネス オブジェクトを移行し、登録を行う（调用业务对象执行注册）
//            as.insertCustomer1(cp);
//            // 反応成功（响应成功）
//            result.setState(200);
//        } catch (Exception e) {
//            // ユーザネームは使用された（用户名被占用）
//            result.setState(4000);
//            result.setMessage("异常发生");
//        }
//        // 結果を戻す
//        return result;
//    }
//
//
////    @RequestMapping("/goIndex")
////    public String goIndex(Model model) {
////        List<Customer> customers = as.selectAll();
////        model.addAttribute("customerList", customers);
////        return "index";
////    }
//
//}
