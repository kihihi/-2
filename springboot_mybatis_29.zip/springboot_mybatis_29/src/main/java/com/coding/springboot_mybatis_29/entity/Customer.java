package com.coding.springboot_mybatis_29.entity;

public class Customer {

    private Integer id;

    private String name;

    private String sex;

    private Integer score;

    private String tel;

    public Customer(Integer id, String name, String sex, Integer score, String tel) {
        this.id = id;
        this.name = name;
        this.sex = sex;
        this.score = score;
        this.tel = tel;
    }

    public Customer() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
}
