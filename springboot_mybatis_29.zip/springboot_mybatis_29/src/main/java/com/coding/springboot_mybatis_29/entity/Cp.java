package com.coding.springboot_mybatis_29.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class Cp {

    @JsonProperty("CP_NameSei")
    //姓（漢字）
    private String CP_NameSei;
    //名（漢字）
    private String CP_NameMei;
    //セイ
    private String CP_NameSeiKana;
    //メイ
    private String CP_NameMeiKana;
    //姓（ローマ字）
    private String CP_AlphLastname;
    //名（ローマ字）
    private String CP_AlphFirstname;
    //国籍
    private String CP_Country;
    //性別
    private String CP_Sex;

    @JsonProperty("CP_BirthDate")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    //生年月日
    private Date CP_BirthDate;
    //職業
    private String CP_ShokugyoCode;
    //勤務先
    private String CP_KinmusakiName;

}
