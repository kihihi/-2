package com.coding.springboot_mybatis_29;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMybatis29ApplicationTests {

    @Test
    void contextLoads() {
    }

}
